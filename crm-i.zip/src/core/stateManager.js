const stateInstances = new WeakMap();

export function useState(initialValue) {
  let currentComponent = window.currentComponent;
  if (!currentComponent) {
    throw new Error('useState must be called inside a component');
  }

  const componentState = stateInstances.get(currentComponent) || {};

  // Инициализация состояния, если его еще нет
  if (!(initialValue in componentState)) {
    componentState[initialValue] = initialValue;
    stateInstances.set(currentComponent, componentState);
  }

  const state = componentState[initialValue];

  function setState(newValue) {
    componentState[initialValue] = newValue;
    stateInstances.set(currentComponent, componentState);
    currentComponent.update(); // Обновляем компонент при изменении состояния
  }

  return [state, setState];
}

export function registerComponent(component) {
  stateInstances.set(component, {});
}
