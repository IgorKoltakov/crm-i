import { registerComponent } from "./stateManager.js";

window.currentComponent = null;

export class CreateComponent {
  constructor(config) {
    this.template = config.template;
    this.selector = config.selector;
    this._methods = {}; // Для хранения методов компонента

    registerComponent(this); // Регистрация компонента в менеджере состояния
  }

  setCurrentComponent() {
    window.currentComponent = this;
  }

  render() {
    this.setCurrentComponent();
    const html = this.template.call(this); // Передаем контекст компонента
    const el = document.querySelector(this.selector);

    if (!el) throw new Error(`Selector ${this.selector} not found`);
    
    el.innerHTML = html;
    initComponentsByTag(el);

    // Привязываем методы компонента
    this.bindMethods(el);
  }

  update() {
    this.render(); // Обновляем рендеринг компонента
  }

  // Метод для добавления методов в контекст компонента
  addMethod(name, method) {
    this._methods[name] = method;
  }

  // Метод для привязки методов к событиям
  bindMethods(el) {
    Object.keys(this._methods).forEach(methodName => {
      const method = this._methods[methodName];

      // Привязываем обработчики для всех типов событий
      const eventTypes = ['click', 'change', 'input', 'submit']; // Добавьте нужные события

      eventTypes.forEach(eventType => {
        const elements = el.querySelectorAll(`[c-on-${eventType}*="${methodName}"]`);
        elements.forEach(element => {
          element.addEventListener(eventType, method.bind(this));
        });
      });
    });
  }
}




export function CRMCreateApp(selector, rootComponent) {
  const container = document.getElementById(selector);

  if (!container) throw new Error(`Container with id ${selector} not found`);

  const jsxCode = rootComponent(); // Получаем JSX код как строку
  console.log('jsxCode', jsxCode);
  
  const vdom = transformJSX(jsxCode); // Преобразуем JSX в виртуальный DOM

  // Рендерим основной шаблон
  container.innerHTML = vdom;

  // Инициализация всех пользовательских компонентов
  initComponentsByTag(container);
}

function initComponentsByTag(root) {
  // Проходим по всем элементам с пользовательскими тегами (например, <Counter>)
  const customTags = root.querySelectorAll('[component]');

  customTags.forEach(tag => {
    
    const componentName = tag.getAttribute('component');
    const ComponentClass = window[componentName]; // Динамическое обращение к классу компонента

    if (ComponentClass) { 
      const instance = ComponentClass;
      instance.render();
      
    } else {
      console.warn(`Component ${componentName} not found`);
    }
  });
}
