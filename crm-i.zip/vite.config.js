import { defineConfig } from 'vite';
import react from '@vitejs/plugin-react';

export default defineConfig({
  plugins: [react()], // Подключаем плагин для поддержки JSX
  build: {
    lib: {
      entry: './src/index.js',
      name: 'crm-i',
      fileName: (format) => `crm-i.${format}.js`,
    },
  },
});
