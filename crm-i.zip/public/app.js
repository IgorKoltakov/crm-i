import { CRMCreateApp } from '../src/index.js';
import './Counter.js';

// CRMCreateApp('root', () => {
//   // return (
//   //   <Counter component="Counter"/>
//   // );
// });