import { CreateComponent, useState } from '../src/index.js';

// Функциональный компонент
function CounterComponent() {
  const [count, setCount] = useState(0);
  const [input, setInput] = useState('');

  function increment() {
    setCount(count + 1);
  }

  function handleInput(event) {
    setInput(event.target.value);
  }

  // Регистрация методов
  this.addMethod('increment', increment);
  this.addMethod('handleInput', handleInput);

  return (
    <div>
      <p>Count: {count}</p>
      <p>Count: {input}</p>
      <button onClick={increment}>Increment</button>
      <input type="text" onInput={handleInput} />
    </div>
  );
}

export const Counter = new CreateComponent({
  selector: 'Counter',
  template: CounterComponent,
});

// Регистрация компонента в глобальном объекте
window.Counter = Counter;
